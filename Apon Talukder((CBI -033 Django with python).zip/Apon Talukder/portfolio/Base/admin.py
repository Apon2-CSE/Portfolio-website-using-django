from django.contrib import admin
from Base.models import Contact 
# Register your models here.
admin.site.register(Contact)